Warning!

Please run the program by executing the "open me" file!

Please run this program on cmd or your terminal (Recommended)

Terminate the cmd to close all the pop up!

If any error appear please install the following requements first!

Made by Jose :)