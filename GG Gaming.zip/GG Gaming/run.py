import subprocess

subprocess.run(["python", "gg.py"])
subprocess.run(["python", "1.py"])
subprocess.run(["python", "pro.py"])
subprocess.run(["python", "run2.py"])
